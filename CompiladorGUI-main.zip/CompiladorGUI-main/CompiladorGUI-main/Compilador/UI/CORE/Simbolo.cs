﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compilador.UI.CORE
{
    public class Simbolo
    {
        public string Nombre { get; set; }
        public string Tipo { get; set; }
        public int Linea { get; set; }

        public Simbolo(string nombre, string tipo, int linea)
        {
            Nombre = nombre;
            Tipo = tipo;
            Linea = linea;
        }
    }
}
